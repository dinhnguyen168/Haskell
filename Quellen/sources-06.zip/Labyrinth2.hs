module Labyrinth2 where

-- Modelling undirected labyrinths

-- An identifier for the nodes:
type Id  = Integer

-- The passageways in the labyrinth:
data Lab = Dead Id Lab
         | Pass Id Lab Lab 
         | TJnc Id Lab Lab Lab

-- Get identity of a node
nid :: Lab-> Id
nid (Dead i _) = i
nid (Pass i _ _) = i
nid (TJnc i _ _ _)= i

-- A path in the labyrinth (essentially, a list of node identifiers):
data Path = Cons Id Path
          | Mt
          deriving (Eq, Show)

-- Checks wether a node is contained in a path
contains :: Id-> Path-> Bool
contains _ Mt = False
contains i (Cons j js) = i == j || contains i js

-- Add single node at the back of a path
snoc :: Path-> Id-> Path
snoc Mt i = Cons i Mt
snoc (Cons j js) i = Cons j (snoc js i)

-- A traversal: a successful path, or a failure:
data Trav = Succ Path
          | Fail
          deriving (Eq, Show)

-- Add a node to a traversal, if successful:
cons :: Id-> Trav-> Trav
cons _ Fail      = Fail
cons i (Succ is) = Succ (Cons i is)

-- Add two traversals, disregarding first if it fails:
select :: Trav-> Trav-> Trav
select Fail t = t
select t    _ = t

-- Traversal of a labyrinth to a given node:
traverse3 :: Id-> Lab-> Path-> Trav
traverse3 t l p
  | nid l == t = Succ (snoc p (nid l))
  | contains (nid l) p = Fail
  | otherwise = case l of
    Dead i n -> traverse3 t n (snoc p i)
    Pass i n m -> select (traverse3 t n (snoc p i))
                         (traverse3 t m (snoc p i))
    TJnc i n m k -> select (traverse3 t n (snoc p i))
                           (select (traverse3 t m (snoc p i))
   		                   (traverse3 t k (snoc p i)))


-- The example labyrinth (now undirected)
l00 = Pass 0 l10 l01
l10 = Dead 1 l00       -- "Entrance"
l20 = Pass 2 l30 l21
l30 = Pass 3 l20 l31
l40 = Dead 4 l41
l01 = TJnc 5 l00 l11 l02
l11 = Pass 6 l01 l21
l21 = Pass 7 l11 l20
l31 = TJnc 8 l30 l41 l32
l41 = TJnc 9 l40 l31 l42
l02 = TJnc 10 l10 l12 l03
l12 = Pass 11 l02 l13
l22 = Pass 12 l23 l32 
l32 = Pass 13 l22 l31
l42 = Dead 14 l41
l03 = Pass 15 l02 l04
l13 = Pass 16 l12 l23
l23 = TJnc 17 l13 l22 l24 
l33 = Pass 18 l34 l43
l43 = Pass 19 l33 l44
l04 = Pass 20 l03 l14
l14 = Pass 21 l04 l24  
l24 = TJnc 22 l23 l14 l34  
l34 = Pass 23 l24 l33
l44 = Dead 24 l43
