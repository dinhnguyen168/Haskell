module FacFold where

import Data.List(foldl')

fac_foldr :: Integer-> Integer
fac_foldr i = foldr (*) 1 [1.. i]

fac_foldl :: Integer-> Integer
fac_foldl i = foldl (*) 1 [1.. i]

fac_foldl' :: Integer-> Integer
fac_foldl' i = foldl' (*) 1 [1.. i] 
