module Fac3 where

fac3 :: Integer-> Integer
fac3 n = fac' n 1 where 
  fac' n acc = seq acc (if n == 0 then acc 
                        else fac' (n-1) (n*acc))

