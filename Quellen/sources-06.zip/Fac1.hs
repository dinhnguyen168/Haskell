module Fac1 where

fac1 :: Integer-> Integer
fac1 n  = if n == 0 then 1 else n * fac1 (n-1) 
