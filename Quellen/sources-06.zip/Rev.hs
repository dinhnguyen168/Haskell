module Rev where

rev' :: [a]-> [a]
rev' []     = []
rev' (x:xs) = rev' xs ++ [x]    

rev :: [a]-> [a]
rev xs = rev0 xs [] where
    rev0 []     ys = ys
    rev0 (x:xs) ys = rev0 xs (x:ys)
