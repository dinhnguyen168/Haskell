module Fac2 where

fac2 :: Integer-> Integer
fac2 n     = fac' n 1 where
  fac' :: Integer-> Integer-> Integer
  fac' n acc = if n == 0 then acc 
               else fac' (n-1) (n*acc)
