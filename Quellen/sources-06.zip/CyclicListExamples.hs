import Debug.Trace(trace)

ones :: [Integer]
ones = 1 : ones

nats :: [Integer]
nats = natsfrom 0 where
  natsfrom i = i: natsfrom (i+1)

fives :: [Integer]
fives = trace "*** Foo! ***" 5 : fives
