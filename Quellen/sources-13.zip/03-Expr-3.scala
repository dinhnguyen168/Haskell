// Evaluate an expression with a map for the variables
def eval(env: Map[String, Double]) (expr: Expr): Double = expr match {
   case Var(v) => env(v)    // Look up variable name in Map
   case Num(x) => x
   case Plus(e1, e2) => eval(env)(e1) + eval(env)(e2)
   case Minus(e1, e2) => eval(env)(e1) - eval(env)(e2)
   case Times(e1, e2) => eval(env)(e1) * eval(env)(e2)
   case Div(e1, e2) => eval(env)(e1) / eval(env)(e2)
   }


val g = Map("x" -> 7.0, "pi" -> 3.14159)

val e = Times(Var("pi"), Div(Var("x"), Num(3.5)))

