object Main {
  def main(args: Array[String]) : Unit = {
    for (arg<- args)
       println(arg)
  }
// Andere Moeglichkeiten:
  def main2(args: Array[String]) : Unit = {
    args.foreach(println)
  }

  def main3(args: Array[String]) : Unit = {
    args map println
  }      
}
