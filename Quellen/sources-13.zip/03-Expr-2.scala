
// Evaluating an expression 
def eval(expr: Expr): Double = expr match {
   case v: Var => 0    // Variables evaluate to 0
   case Num(x) => x
   case Plus(e1, e2) => eval(e1) + eval(e2)
   case Minus(e1, e2) => eval(e1) - eval(e2)
   case Times(e1, e2) => eval(e1) * eval(e2)
   case Div(e1, e2) => eval(e1) / eval(e2)
   }

val e = Times(Num(12), Plus(Num(2.3),Num(3.7)))
