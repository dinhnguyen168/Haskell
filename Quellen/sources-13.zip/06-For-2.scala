val l1 = (1 to 10).toList

def half(x: Int): Option[Int] = 
  if (x % 2 == 0) Some (x / 2) else None;

for { x<- l1; y<- half(x) } yield y;

