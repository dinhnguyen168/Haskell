val l1 = 1 :: 2 :: 3 :: 4 :: 5 :: 6 :: 7 :: 8 :: 9 :: 10 :: Nil
val l2 = 1 to 10

for { x<- l1; if (x % 2 == 0) } yield 2*x+1;

