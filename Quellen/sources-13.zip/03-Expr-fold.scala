
abstract class Expr {
  def fold[A]( v: String=> A
             , n: Double=> A 
             , p: (A, A)=> A 
             , m: (A, A)=> A 
             , t: (A, A)=> A 
             , d: (A, A)=> A): A = this match 
    {
      ??
    } 
}
case class Var(name: String) extends Expr
case class Num (num: Double) extends Expr
case class Plus (left: Expr, right: Expr) extends Expr
case class Minus (left: Expr, right: Expr) extends Expr
case class Times (left: Expr, right: Expr) extends Expr
case class Div (left: Expr, right: Expr) extends Expr
