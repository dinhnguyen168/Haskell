class Ref[T](init: T) {
  private var curr = init
  def get : T = curr 
  def set(x: T) : Unit = { curr= x } 
  }

/*

Wenn sich dies uebersetzen liesse, koennten wir beliebige 
Typen ineinander konvertieren: Typsicherheit ade!

val c1= new Ref[String]("abc")
val c2: Ref[Any]= c1
c2.set(1)
val s: String= c1.get

 */
