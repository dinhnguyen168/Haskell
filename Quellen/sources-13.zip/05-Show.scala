// "Typklasse"
trait Show[T] {
  def show(value: T): String
}

// Instanzen
implicit object ShowInt extends Show[Int] {
  def show(value: Int) = "Int: "+ value.toString
}

implicit object ShowString extends Show[String] {
  def show(value: String) = s"String: $value"
}

// Benutzung
def print[T](value: T)(implicit show: Show[T])= {
  println(show.show(value));
}
