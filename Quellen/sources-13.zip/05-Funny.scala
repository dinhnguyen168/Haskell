trait Funny {
  def laugh: Unit = println("Hahaha!") 
  }

class X {
  override def toString = "x stands for unknown"
  }

class Y extends X with Funny {
  def cry : Unit = println("Boohoo.")
}