
-- Fakult�t, revisited
fac' :: Integer-> Integer-> Integer
fac' n r =
  if n <= 0 then r
  else fac' (n-1) (n*r)

fac :: Integer-> Integer
fac n = fac' n 1
