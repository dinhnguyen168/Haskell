
-- An undefined function -- evaluation never terminates
undef :: String
undef = undef

-- An undefined function -- evaluation terminates with exception
undef2 :: String
undef2 = error "Undefined value"
