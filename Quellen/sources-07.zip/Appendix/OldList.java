import java.lang.System;

class List {
  public List(Object el, List tl) {
    this.elem= el;
    this.next= tl;
  }
  public Object elem;
  public List   next;

  /* Length, iterative */
  int length() {
    int i= 0;
    for (List cur= this; cur != null; cur= cur.next)
      i++;
    return i;
  }

  public static void main(String[] args)
  {
    List l= new List(new Integer(1), new List(new Integer(2), null));
      
    System.out.println("length: "+ l.length()); 
  }
	    

}
      
	
