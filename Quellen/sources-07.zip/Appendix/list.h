/* Lists in C */

typedef struct list_t {
     void          *elem;
     struct list_t *next;
     } *list;

extern list cons(void* hd, list tl);
extern int length(list l);
extern list map1(void *(*f)(void *x), list l);
extern list map2(void *(*f)(void *x), list l);
extern list map3(void *(*f)(void *x), list l);
extern void map4(void (*f)(void *x), list l);
extern list filter(int(*f)(void *x), list l);
