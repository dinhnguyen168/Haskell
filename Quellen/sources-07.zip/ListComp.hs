module ListComp where

import Data.Char

-- Examples for list comprehension:

digits :: String-> [Int]
digits str = [ord x -ord '0'| x<- str, isDigit x]        

idx:: [String]
idx = [ a: show i| a<- ['a'.. 'z'], i<- [0.. 9]]


