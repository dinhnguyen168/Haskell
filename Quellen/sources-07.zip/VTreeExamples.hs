module VTreeExamples where

import VTree

-- A simple example without cycles
{-- simple1 --}
s0 = NT 0 [s1, s2]
s1 = NT 1 []
s2 = NT 2 [s3]
s3 = NT 3 [s1, s4]
s4 = NT 4 []
{-- end --}

-- A simple example with cycles
{-- simple2 --}
t0 = NT 0 [t2]
t1 = NT 1 [t0]
t2 = NT 2 [t3]
t3 = NT 3 [t1, t4]
t4 = NT 4 []
{-- end --}
