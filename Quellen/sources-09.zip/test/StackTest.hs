module Main where

import Stack
import Test.Tasty
import qualified Test.Tasty.QuickCheck as QC
import Test.Tasty.QuickCheck((==>))

-- Arbitrary-Instanz f�r Stack
-- Erzeugt einen Stack zuf�lliger L�nge zwischen 0 und 20, 
-- gef�llt mit zuf�lligen Werten.
instance QC.Arbitrary alpha=> QC.Arbitrary (St alpha) where
  arbitrary = do
    size <- QC.choose (0, 20) 
    els  <- QC.vector size     
    return $ foldr push empty els

main =
  defaultMain $ localOption (QC.QuickCheckTests 5000) $
    testGroup "All stack tests"
    [ QC.testProperty "top_push" $ \a s ->
        top (push a (s :: St Int)) == a
    , QC.testProperty "pop_push" $ \a s ->
        pop (push a (s :: St Int)) == s
    , QC.testProperty "push not empty" $ \a s ->
        empty /= push a (s:: St Int)
    ]

