module MapFun(
  Map, empty, lookup, put)
where

import Prelude hiding(lookup)

data Map alpha beta = Map (alpha-> Maybe beta)

empty :: Map alpha beta
empty = Map (\x-> Nothing)

lookup :: Eq alpha=> alpha-> Map alpha beta-> Maybe beta
lookup a (Map s) = s a

put :: Eq alpha=> alpha-> Maybe beta-> Map alpha beta-> Map alpha beta
put a b (Map s) = 
  Map (\x-> if x == a then b else s x)

-- Keine Instanz f�r Eq und Show m�glich
