module Map(
   Map
 , empty
 , lookup
 , insert
 , delete
 ) where

import Prelude hiding (lookup)

-- import MapFun
-- import MapList
import MapTree


-- Thin-to-rich interface

insert :: Ord alpha=> alpha-> beta-> Map alpha beta-> Map alpha beta
insert a v = put a (Just v)

delete :: Ord alpha=> alpha-> Map alpha beta-> Map alpha beta
delete a = put a Nothing
