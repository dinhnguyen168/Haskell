module Shoppe where

import Artikel
import Lager
import Einkaufswagen

{- Examples: -}

w0= leererWagen
w1= einkauf (Apfel Boskoop) (Stueck 3) w0                               
w2= einkauf Schinken (Gramm 50) w1
w3= einkauf (Milch Bio) (Liter 1) w2
w4= einkauf Schinken (Gramm 50) w3

l0= leeresLager
l1= einlagern (Apfel Boskoop) (Stueck 1) l0
l2= einlagern Schinken (Gramm 50) l1
l3= einlagern (Milch Bio) (Liter 6) l2
l4= einlagern (Apfel Boskoop) (Stueck 4) l3
l5= einlagern (Milch Bio) (Liter 4) l4
l6= einlagern Schinken (Gramm 50) l5
