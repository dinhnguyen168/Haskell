module MapTest where

import MapTree


-- Test trees
tt :: [Int]-> Map Int String
tt = foldl (\t n -> insert n (show n) t) empty

t1 = tt [4,5,7,2,1,3,6,8,9]
t2 = tt [3,1,4,3]

