-- Hindley-Milner type inference is exponential -- Demo.

f1 x = (x, x)
f2 x = f1 (f1 x)
f3 x = f2 (f2 x)
f4 x = f3 (f3 x)
f5 x = f4 (f4 x)
-- f6 x = f5 (f5 x)    -- This is the killer!


-- Attribution: I know this from Don Sannella, not sure of original source.
