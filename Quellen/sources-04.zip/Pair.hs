module Pair where

-- Pairs with selectors
data Pair alpha beta = Pair { left :: alpha, right :: beta }
                       deriving (Show, Eq)

-- An example function
twist :: Pair alpha beta -> Pair beta alpha
twist (Pair a b) = Pair b a

