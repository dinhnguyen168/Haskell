
forN :: Int-> IO a-> IO [a]
forN n a |n == 0     = return []
         | otherwise = do x<- a; xs<- forN (n-1) a; return $ x:xs 

forN' :: Int-> IO a-> IO [a]
forN' n a = run n [] where
    run n acc | n == 0  = return $ reverse acc
              | otherwise = do x<- a; run (n-1) (x:acc)


forN'' :: Int-> IO a-> IO [a]
forN'' n a = sequence (replicate n a)