import System.Random(randomRIO)

while :: IO Bool -> IO alpha-> IO ()
while c b = do a<- c; if a then b >> while c b else return ()

while2 :: IO Bool-> IO alpha-> IO [alpha]
while2 c b = do
  a <- c
  if a then do { x<- b; xs <- while2 c b; return (x: xs) } else return []

while3 :: IO Bool-> IO alpha-> IO [alpha]
while3 c b = run [] where
  run l = do a <- c;
             if a then do x<- b; run  (x:l) else return $ reverse l


test :: IO Bool
test = do x<- randomRIO (0,3 :: Int); return $ 0 < x
