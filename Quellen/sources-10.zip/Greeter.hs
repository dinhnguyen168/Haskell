module Greeter where

{-- greeter --}
greeter :: IO ()
greeter = do
  putStr "What's your name, love? "
  s <- getLine
  putStrLn $ "Hullo, " ++ s ++ ". Pleased to meet you."
