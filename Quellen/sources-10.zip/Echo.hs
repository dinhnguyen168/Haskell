-- Echo einfach
{-- echo1 --}
echo1 :: IO ()
echo1 = getLine >>= putStrLn
{-- end --}

-- Echo mehrfach
{-- echo --}
echo :: IO ()
echo = getLine >>= putStrLn >>= \_ -> echo
{-- end --}

-- Echo ruewaerts
{-- ohce --}
ohce :: IO ()
ohce = getLine >>= \s-> putStrLn (reverse s) >> ohce
{-- end --}

-- Zaehlendes, endliches Echo
{-- echo3 --}
echo3 :: Int-> IO ()
echo3 cnt = do
  putStr (show cnt ++ ": ")
  s<- getLine
  if s /= "" then do 
      putStrLn $ show cnt ++ ": "++ s
      echo3 (cnt+ 1)
    else return ()
{-- end --}

-- Echo umgekehrt in "punktfreier" Notation
{-- ohce2 --}
oche2 :: IO ()
oche2 = getLine
         >>= putStrLn . reverse
         >> oche2
{-- end --}
