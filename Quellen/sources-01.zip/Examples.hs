-- Diese Zeile versteckt die vordefinierte Funktion "repeat"
import Prelude hiding (repeat)

fac    :: Int-> Int
fac n = if n == 0 then 1 else n* fac(n-1)


repeat :: Int-> String-> String
repeat n s = if n == 0 then "" else s ++ repeat (n-1) s


stars  :: Int-> String
stars n = if n > 1 then stars (div n 2) ++ "*" else "" 

