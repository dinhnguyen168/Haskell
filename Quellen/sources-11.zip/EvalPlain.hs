module EvalPlain where

import Expr

eval :: Expr -> Double
eval (Var _)  = 0
eval (Num n)  = n
eval (Plus a b)  = eval a+ eval b
eval (Minus a b) = eval a- eval b
eval (Times a b) = eval a* eval b
eval (Div a b)   = eval a/ eval b

